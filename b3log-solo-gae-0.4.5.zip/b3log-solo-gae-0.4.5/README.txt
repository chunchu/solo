B3log Solo is an open source Java blogging program.

Project home: https://github.com/b3log/b3log-solo
Request features/Report bugs: https://github.com/b3log/b3log-solo/issues/new

* QQ Qun: 13139268
* User Guide: http://code.google.com/p/b3log-solo/wiki/UserGuide
* Dev Guide: http://code.google.com/p/b3log-solo/wiki/pre_dev
  * Skin Dev Guide: http://code.google.com/p/b3log-solo/wiki/develop_steps
  * Plugin Dev Guide: https://docs.google.com/document/pub?id=15H7Q3EBo-44v61Xp_epiYY7vK_gPJLkQaT7T1gkE64w&pli=1

====
B3log Index: http://b3log.org

B3log Team: http://code.google.com/p/b3log-solo/wiki/about_us
Join B3log Team: http://code.google.com/p/b3log-solo/wiki/join_us
====

平等，自由，奔放
Equality, Freedom, Passion

;-)
