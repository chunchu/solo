/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *  index for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.1.1, Aug 24, 2011
 */

var Admin = function () {
    this.register = {};
    // 工具栏下的工具
    this.tools = ['#page-list', '#file-list', '#link-list', '#preference', 
    '#user-list', '#plugin-list', '#others'];
    // 多用户时，一般用户不能使用的功能
    this.adTools = ['link-list', 'preference', 'file-list', 'page-list', 'others', 
    'user-list', 'plugin-list'];
};

$.extend(Admin.prototype, {    
    /*
     * 登出
     */
    logout: function () {
        var logoutURL = jsonRpc.adminService.getLogoutURL();
        window.location.href = logoutURL;
    },
    
    /*
     * 根据当前页数设置 hash
     * @currentPage {string} 当前页
     */
    setHashByPage: function (currentPage) {
        var hash = window.location.hash,
        hashList = hash.split("/");
        if (/^\d*$/.test(hashList[hashList.length - 1])) {
            hashList[hashList.length - 1] = currentPage;
        } else {
            hashList.push(currentPage);
        }
        window.location.hash = hashList.join("/");
    },
    
    /*
     * 设置某个 tab 被选择
     * @id tab id
     */
    selectTab: function (id) {
        window.location.hash = "#" + id;
       
    },
    
    /*
     * 根据当前 hash 解析出当前页数及 hash 数组。
     */
    analyseHash: function () {
        var hash = window.location.hash;
        var tag = hash.substr(1, hash.length - 1);
        var tagList = tag.split("/");
        var tags = {};
        tags.page = 1,
        tags.hashList = [];
        for (var i = 0; i < tagList.length; i++) {
            if (i === tagList.length - 1) {
                if (/^\d+$/.test(tagList[i])) {
                    tags.page = tagList[i];
                } else {
                    tags.hashList.push(tagList[i]);
                }
            } else {
                tags.hashList.push(tagList[i]);
            }
        }
        return tags;
    },
    
    /*
     * 根据当前 hash 设置当前 tab
     */
    setCurByHash: function () {
        var tags = this.analyseHash();
        var tab = tags.hashList[1], 
        subTab = tags.hashList[2];
        
        if (tags.hashList.length === 1) {
            tab = tags.hashList[0];
        }
        
        if (tab === "") {
            return;
        }
        
        // 离开编辑器时进行提示
        if (tinyMCE) {
            if (tinyMCE.get('articleContent')) {
                // 除更新、发布、取消发布文章，编辑器中无内容外，离开编辑器需进行提示。
                if (tab !== "article" && admin.article.isConfirm &&
                    tinyMCE.get('articleContent').getContent().replace(/\s/g, '') !== "") {
                    if (!confirm(Label.editorLeaveLabel)) {
                        window.location.hash = "#article/article";
                        return;
                    }
                }
                // 不离开编辑器，hash 需变为 "#article/article"，此时不需要做任何处理。
                if (tab === "article" && admin.article.isConfirm &&
                    tinyMCE.get('articleContent').getContent().replace(/\s/g, '') !== "") {
                    return;
                }
            }
        }
        
        // clear article 
        if (tab !== "article") {
            admin.article.clear();
        }
        admin.article.isConfirm = true;
        
        $("#tabs").tabs("setCurrent", tab);
        $("#loadMsg").text(Label.loadingLabel);
        
        if ($("#tabsPanel_" + tab).length === 1) {
            if ($("#tabsPanel_" + tab).html().replace(/\s/g, "") === "") {
                // 还未加载 HTML
                $("#tabsPanel_" + tab).load("admin-" + tab + ".do", function () {
                    // 页面加载完后，回调初始函数
                    if (tab === "article" && admin.article.status.id) {
                        // 当文章页面编辑器未初始化时，调用更新文章需先初始化编辑器
                        admin.register[tab].init.call(admin.register[tab].obj, admin.article.getAndSet);
                    } else {
                        admin.register[tab].init.call(admin.register[tab].obj, tags.page);
                    }
                
                    // 页面包含子 tab，需根据 hash 定位到相应的 tab
                    if (subTab) {
                        $("#tabPreference").tabs("setCurrent", subTab);
                    }
                
                    // 根据 hash 调用现有的插件函数
                    admin.plugin.setCurByHash(tags);
                });
            } else {
                if (tab === "article" && admin.article.status.id) {
                    admin.article.getAndSet();
                }
            
                // 已加载过 HTML，只需调用刷新函数
                if (admin.register[tab] && admin.register[tab].refresh) {
                    admin.register[tab].refresh.call(admin.register[tab].obj, tags.page);
                }
            
                // 页面包含子 tab，需根据 hash 定位到相应的 tab
                if (subTab) {
                    $("#tabPreference").tabs("setCurrent", subTab);
                }
                
                // 根据 hash 调用现有的插件函数
                admin.plugin.setCurByHash(tags);
            }  
        } else {
            alert("Error: No tab!\n" + Label.reportIssueLabel);
        }
    },
    
    /*
     * 初始化整个后台
     */
    init: function () {
        //window.onerror = Util.error;
        
        Util.killIE();   
        $("#loadMsg").text(Label.loadingLabel);
        
        // 构建 tabs
        $("#tabs").tabs();
            
        // tipMsg
        setInterval(function () {
            if($("#tipMsg").text() !== "") {
                setTimeout(function () {
                    $("#tipMsg").text("");
                }, 7000);
            }
        }, 6000);
        $("#loadMsg").text("");
    },
    
    /*
     * tools and article collapse
     * @it 触发事件对象
     */
    collapseNav: function (it) {
        var subNav = $(it).next()[0];
        if (subNav.className === "none") {
            $(it).find(".ico-arrow-down")[0].className = "ico-arrow-up";
            subNav.className = "collapsed";
        } else {
            $(it).find(".ico-arrow-up")[0].className = "ico-arrow-down";
            subNav.className = "none";
        }
    },
    
    /*
    * 后台及当前页面所需插件初始化完后，对权限进行控制及当前页面属于 tools 时，tools 选项需展开。
    */
    inited: function () {
        // Removes functions with the current user role
        if (Label.userRole !== "adminRole") {
            for (var i = 0; i < this.adTools.length; i++) {
                $("#tabs").tabs("remove", this.adTools[i]);
            }
            $("#tabs>ul>li").last().remove();
        } else {
            // 当前 tab 属于 Tools 时，设其展开
            for (var j = 0; j < this.tools.length; j++) {
                if ("#" + window.location.hash.split("/")[1] === this.tools[j]) {
                    $("#tabToolsTitle").click();
                    break;
                }
            }
        }
        this.setCurByHash();
    }
});
var admin = new Admin();/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * table and paginate util
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.6, Aug 19, 2011
 */

var TablePaginate = function (id) {
    this.id = id;
    this.currentPage = 1;
};

$.extend(TablePaginate.prototype, {
    /*
     * 构建 table 框架
     * @colModel table 列宽，标题等数据
     */
    buildTable: function (colModel, noExpend) {
        var tableData = {
            colModel: colModel
        }
        if (!noExpend) {
            tableData.expendRow = {
                index: "expendRow"
            }
        }
        $("#" + this.id + "Table").table(tableData);
    
    },
    
    /*
     * 初始化分页
     */
    initPagination: function () {
        var id = this.id;
        $("#" + id + "Pagination").paginate({
            "bind": function(currentPage) {
                admin.setHashByPage(currentPage);
                return true;
            },
            "currentPage": 1,
            "errorMessage": Label.inputErrorLabel,
            "nextPageText": Label.nextPagePabel,
            "previousPageText": Label.previousPageLabel,
            "goText": Label.gotoLabel,
            "type": "custom",
            "custom": [1],
            "pageCount": 1
        });
    },

    /*
     * 初始化评论对话框
     */
    initCommentsDialog: function () {
        var that = this;
        $("#" + this.id + "Comments").dialog({
            width: 700,
            height:500,
            "modal": true,
            "hideFooter": true,
            "close": function () {
                admin[that.id + "List"].getList(that.currentPage);
                return true;
            }
        });
    },
    
    /*
     * 更新 table & paginateion
     */
    updateTablePagination: function (data, currentPage, pageInfo) {
        currentPage = parseInt(currentPage);
        if (currentPage > pageInfo.paginationPageCount && currentPage > 1) {
            alert(Label.pageLabel + ":" + currentPage + " " + Label.noDataLable);
            return;
        }
        $("#" + this.id + "Table").table("update", {
            data: [{
                groupName: "all",
                groupData: data
            }]
        });
                    
        if (pageInfo.paginationPageCount === 0) {
            pageInfo.paginationPageCount = 1;
        }
        
        $("#" + this.id + "Pagination").paginate("update", {
            pageCount: pageInfo.paginationPageCount,
            currentPage: currentPage,
            custom: pageInfo.paginationPageNums
        });
        this.currentPage = currentPage;
    }
});/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *  article for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @author <a href="mailto:DL88250@gmail.com">Liang Ding</a>
 * @version 1.0.1.1, Oct 18, 2011
 */
admin.article = {
    // 当发文章，取消发布，更新文章时设置为 false。不需在离开编辑器时进行提示。
    isConfirm: true,
    status: {
        id: undefined,
        isArticle: undefined,
        articleHadBeenPublished: undefined
    },
    
    /* 
     * 获取文章并把值塞入发布文章页面 
     * @id 文章 id
     * @isArticle 文章或者草稿
     */
    get: function (id, isArticle) {
        this.status.id = id;
        this.status.isArticle = isArticle
        admin.selectTab("article/article");
    },
    
    getAndSet: function () {
        $("#loadMsg").text(Label.loadingLabel);
        var requestJSONObject = {
            "oId": admin.article.status.id
        };
                        
        jsonRpc.articleService.getArticle(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_ARTICLE_SUCC":
                        // set default value for article.
                        $("#title").val(result.article.articleTitle);
                        admin.article.status.articleHadBeenPublished =  result.article.articleHadBeenPublished;
                        if (tinyMCE.get('articleContent')) {
                            tinyMCE.get('articleContent').setContent(result.article.articleContent);
                        } else {
                            $("#articleContent").val(result.article.articleContent);
                        }
                        if (tinyMCE.get('abstract')) {
                            tinyMCE.get('abstract').setContent(result.article.articleAbstract);
                        } else {
                            $("#abstract").val(result.article.articleAbstract);
                        }

                        var tags = result.article.articleTags,
                        tagsString = '';
                        for (var i = 0; i < tags.length; i++) {
                            if (0 === i) {
                                tagsString = tags[i].tagTitle;
                            } else {
                                tagsString += "," + tags[i].tagTitle;
                            }
                        }
                        $("#tag").val(tagsString);
                        $("#permalink").val(result.article.articlePermalink);

                        // signs
                        var signs = result.article.signs;
                        $(".signs button").each(function (i) {
                            if (parseInt(result.article.articleSign_oId) === parseInt(signs[i].oId)) {
                                $("#articleSign" + signs[i].oId).addClass("selected");
                            } else {
                                $("#articleSign" + signs[i].oId).removeClass("selected");
                            }
                        });

                        admin.article.setStatus();
                        $("#tipMsg").text(Label.getSuccLabel);
                        break;
                    case "GET_ARTICLE_FAIL_":
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },
    
    /*
     * 删除文章
     * @id 文章 id
     * @fromId 文章来自草稿夹(draft)/文件夹(article)
     */
    del: function (id, fromId) {
        var isDelete = confirm(Label.confirmRemoveLabel);
        if (isDelete) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "oId": id
            };
            
            jsonRpc.articleService.removeArticle(function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_ARTICLE_SUCC":
                            msg = Label.removeSuccLabel;
                            $("#tipMsg").text(msg);
                            admin[fromId + "List"].getList(1);
                            break;
                        case "REMOVE_ARTICLE_FAIL_FORBIDDEN":
                            $("#tipMsg").text(Label.forbiddenLabel);
                            break;
                        case "REMOVE_ARTICLE_FAIL_":
                            $("#tipMsg").text(Label.removeFailLabel);
                            break;
                        default:
                            $("#tipMsg").text("");
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    },
    
    /*
     * 添加文章
     * @articleIsPublished 文章是否发布过
     */
    add: function (articleIsPublished) {
        if (admin.article.validate()) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var signId = "";
            $(".signs button").each(function () {
                if (this.className === "selected") {
                    signId = this.id.substr(this.id.length - 1, 1);
                }
            });

            var requestJSONObject = {
                "article": {
                    "articleTitle": $("#title").val(),
                    "articleContent": tinyMCE.get('articleContent').getContent(),
                    "articleAbstract": tinyMCE.get('abstract').getContent(),
                    "articleTags": this.trimUniqueArray($("#tag").val()).toString(),
                    "articlePermalink": $("#permalink").val(),
                    "articleIsPublished": articleIsPublished,
                    "articleSign_oId": signId,
                    "postToCommunity": $("#postToCommunity").prop("checked")
                }
            };

            jsonRpc.articleService.addArticle(function (result, error) {
                try {
                    switch (result.status.code) {
                        case "ADD_ARTICLE_FAIL_DUPLICATED_PERMALINK":
                            var msg = Label.addFailLabel + ", " + Label.duplicatedPermalinkLabel;
                            $("#tipMsg").text(msg);
                            break;
                        case "ADD_ARTICLE_FAIL_INVALID_PERMALINK_FORMAT":
                            msg = Label.addFailLabel + ", " + Label.invalidPermalinkFormatLabel;
                            $("#tipMsg").text(msg);
                            break;
                        case "ADD_ARTICLE_SUCC":
                            if (articleIsPublished) {
                                admin.article.status.id = undefined;
                                admin.selectTab("article/article-list");
                            } else {
                                admin.selectTab("article/draft-list");
                            }
                            $("#tipMsg").text(Label.addSuccLabel);
                            admin.article.isConfirm = false;
                            break;
                        default:
                            $("#tipMsg").text(Label.addFailLabel);
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    },
    
    /*
     * 更新文章
     * @articleIsPublished 文章是否发布过 
     */
    update: function (articleIsPublished) {
        if (admin.article.validate()) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var signId = "";
            $(".signs button").each(function () {
                if (this.className === "selected") {
                    signId = this.id.substr(this.id.length - 1, 1);
                }
            });
            
            var requestJSONObject = {
                "article": {
                    "oId": this.status.id,
                    "articleTitle": $("#title").val(),
                    "articleContent": tinyMCE.get('articleContent').getContent(),
                    "articleAbstract": tinyMCE.get('abstract').getContent(),
                    "articleTags": this.trimUniqueArray($("#tag").val()).toString(),
                    "articlePermalink": $("#permalink").val(),
                    "articleIsPublished": articleIsPublished,
                    "articleSign_oId": signId
                }
            };

            jsonRpc.articleService.updateArticle(function (result, error) {
                try {
                    switch (result.status.code) {
                        case "UPDATE_ARTICLE_FAIL_FORBIDDEN":
                            $("#tipMsg").text(Label.forbiddenLabel);
                            break;
                        case "UPDATE_ARTICLE_FAIL_DUPLICATED_PERMALINK":
                            var msg = Label.addFailLabel + ", " + Label.duplicatedPermalinkLabel;
                            $("#tipMsg").text(msg);
                            break;
                        case "UPDATE_ARTICLE_SUCC":
                            if (articleIsPublished){
                                admin.selectTab("article/article-list");
                            } else {
                                admin.selectTab("article/draft-list");
                            }
                            
                            $("#tipMsg").text(Label.updateSuccLabel);
                            // reset article form
                            if (tinyMCE.get("articleContent")) {
                                tinyMCE.get('articleContent').setContent("");
                            } else {
                                $("#articleContent").val("");
                            }
                            if (tinyMCE.get('abstract')) {
                                tinyMCE.get('abstract').setContent("");
                            } else {
                                $("#abstract").val("");
                            }
                            $("#tag").val("");
                            $("#permalink").val("");
                            $(".signs button").each(function (i) {
                                if (i === $(".signs button").length - 1) {
                                    this.className = "selected";
                                } else {
                                    this.className = "";
                                }
                            });
                            admin.article.status.id = undefined;
                            admin.article.isConfirm = false;
                            break;
                        default:
                            $("#tipMsg").text(Label.updateFailLabel);
                            break;
                    }
                    $("loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    },
    
    /*
     * 发布文章页面设置文章按钮、发布到社区等状态的显示
     */
    setStatus: function () {
        // set button status
        if (this.status) {
            if (this.status.isArticle) { 
                $("#unSubmitArticle").show();
                $("#submitArticle").hide();
            } else {
                $("#submitArticle").show();
                $("#unSubmitArticle").hide();
            }
            if (this.status.articleHadBeenPublished) {
                $("#postToCommunityTR").hide();
            } else {
                $("#postToCommunityTR").show();
            }
        } else {
            $("#submitArticle").show();
            $("#unSubmitArticle").hide();
            $("#postToCommunityTR").show();
        }

        $("#postToCommunity").attr("checked", "checked");
    },
    
    /*
     * 清除发布文章页面的输入框的内容
     */
    clear: function () {
        this.status = {
            id: undefined,
            isArticle: undefined,
            articleHadBeenPublished: undefined
        };
        this.setStatus();
        if (tinyMCE.get("articleContent")) {
            tinyMCE.get('articleContent').setContent("");
        } else {
            $("#articleContent").val("");
        }
        if (tinyMCE.get('abstract')) {
            tinyMCE.get('abstract').setContent("");
        } else {
            $("#abstract").val("");
        }
        $("#tag").val("");
        $("#title").val("");
        $("#permalink").val("");
        $(".signs button").each(function (i) {
            if (i === 0) {
                this.className = "selected";
            } else {
                this.className = "";
            }
        });
    },
    
    /*
     * 初始化发布文章页面
     */
    init: function (fun) {
        //admin.article.clear();
        // Inits Signs.
        jsonRpc.preferenceService.getSigns(function (result, error) {
            try {
                $(".signs button").each(function (i) {
                    // Sets signs.
                    if (i === result.length) {
                        $("#articleSign1").addClass("selected");
                    } else {
                        $("#articleSign" + result[i].oId).tip({
                            content: result[i].signHTML === "" ? Label.signIsNullLabel : result[i].signHTML.replace(/\n/g, "").replace(/<script.*<\/script>/ig, ""),
                            position: "top"
                        });
                    }
                    // Binds checkbox event.
                    $(this).click(function () {
                        if (this.className !== "selected") {
                            $(".signs button").each(function () {
                                this.className = "";
                            });
                            this.className = "selected";
                        }
                    });
                });
            } catch(e) {
                console.error(e);
            }
        });
        
        // tag auto completed
        jsonRpc.tagService.getTags(function (result, error) {
            try {
                if (result.length > 0) {
                    var tags = [];
                    for (var i = 0; i < result.length; i++) {
                        tags.push(result[i].tagTitle);
                    }
                    $("#tag").completed({
                        height: 160,
                        data: tags
                    });
                }
            } catch (e) {}
            
            $("#loadMsg").text("");
        });

        // submit action
        $("#submitArticle").click(function () {
            if (admin.article.status.id) {
                admin.article.update(true);
            } else {
                admin.article.add(true);
            }
        });
        
        $("#saveArticle").click(function () {
            if (admin.article.status.id) {
                admin.article.update(admin.article.status.isArticle);
            } else {
                admin.article.add(false);
            }
        });

        // editor
        var language = Label.localeString.substring(0, 2);
        if (language === "zh") {
            language = "zh-cn";
        }
        tinyMCE.init({
            // General options
            language: language,
            mode : "exact",
            elements : "articleContent, abstract",
            theme : "advanced",
            plugins : "autosave,style,advhr,advimage,advlink,preview,inlinepopups,media,paste,fullscreen,syntaxhl",

            // Theme options
            theme_advanced_buttons1 : "forecolor,backcolor,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,formatselect,fontselect,fontsizeselect",
            theme_advanced_buttons2 : "bullist,numlist,outdent,indent,|,undo,redo,|,sub,sup,blockquote,charmap,image,iespell,media,|,advhr,link,unlink,anchor,cleanup,|,pastetext,pasteword,code,preview,fullscreen,syntaxhl",
            theme_advanced_buttons3 : "",
            theme_advanced_toolbar_location : "top",
            theme_advanced_toolbar_align : "left",
            theme_advanced_resizing : true,

            extended_valid_elements: "pre[name|class],iframe[src|width|height|name|align]",

            relative_urls: false,
            remove_script_host: false,
            oninit : function () {
                if (typeof(fun) === "function") {
                    fun();
                }
            }
        });
    },
    
    /*
     * 验证发布文章字段的合法性
     */
    validate: function () {
        if ($("#title").val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.titleEmptyLabel);
            $("#title").focus().val("");
        } else if (tinyMCE.get('articleContent').getContent().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.contentEmptyLabel);
        } else if ($("#tag").val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.tagsEmptyLabel);
            $("#tag").focus().val("");
        } else if(tinyMCE.get('abstract').getContent().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.abstractEmptyLabel);
        } else {
            return true;
        }
        return false;
    },
    
    /*
     * 取消发布
     */
    unPublish: function () {
        jsonRpc.articleService.cancelPublishArticle(function (result, error) {
            try {
                if (result.sc === "CANCEL_PUBLISH_ARTICLE_SUCC") {
                    $("#tipMsg").text(Label.unPulbishSuccLabel);
                    admin.selectTab("article/draft-list");
                    admin.article.status.id = undefined;
                    admin.article.isConfirm = false;
                } else {
                    $("#tipMsg").text(Label.unPulbishFailLabel);
                }
            } catch (e) {}
        }, {
            oId: admin.article.status.id
        });
    },
    
    trimUniqueArray: function(str){
        str = str.toString();
        var arr = str.split(",");
        for(var i = 0; i < arr.length; i++) {
            arr[i] = arr[i].replace(/(^\s*)|(\s*$)/g,"");
            if( arr[i] === "" ){
                arr.splice(i, 1);
                i--
            }
        }
        var unique =  $.unique(arr);
        return unique.toString();
    },
    
    /*
     * 点击发文文章时的处理
     */
    prePost:function () {
        if (window.location.hash === "#article/article" && 
            tinyMCE.get('articleContent').getContent().replace(/\s/g, '') !== "") {
            if (confirm(Label.editorPostLabel)) {
                admin.article.clear();
            }
        }
    }
}

/*
 * 注册到 admin 进行管理 
 */
admin.register.article =  {
    "obj": admin.article,
    "init": admin.article.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *  common comment for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.2, Aug 19, 2011
 */

admin.comment = { 
    /*
     * 打开评论窗口
     * @id 该评论对应的 id
     * @fromId 该评论来自文章/草稿/自定义页面
     */
    open: function (id, fromId) {
        this.getList(id, fromId);
        $("#" + fromId + "Comments").dialog("open");
    },
    
    /*
     * 获取评论列表
     * @id 该评论对应的 id
     * @fromId 该评论来自文章/草稿/自定义页面
     */
    getList: function (articleId, fromId) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#" + fromId + "Comments").html("");
        
        var from = "Article";
        if (fromId === "page") {
            from = "Page";
        }
        jsonRpc.commentService["getCommentsOf" + from](function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_COMMENTS_SUCC":
                        var comments = result.comments,
                        commentsHTML = '';
                        for (var i = 0; i < comments.length; i++) {
                            var hrefHTML = "<a target='_blank' href='" + comments[i].commentURL + "'>",
                            content = comments[i].commentContent;
                            contentHTML = Util.replaceEmString(content);
                        
                            if (comments[i].commentURL === "http://") {
                                hrefHTML = "<a target='_blank'>";
                            }

                            commentsHTML += "<div class='comment-title'><span class='left'>"
                            + hrefHTML + comments[i].commentName + "</a>";

                            if (comments[i].commentOriginalCommentName) {
                                commentsHTML += "@" + comments[i].commentOriginalCommentName;
                            }
                            commentsHTML += "</span><span title='" + Label.removeLabel + "' class='right deleteIcon' onclick=\"admin.comment.del('"
                            + comments[i].oId + "', '" + fromId + "', '" + articleId + "')\"></span><span class='right'><a href='mailto:"
                            + comments[i].commentEmail + "'>" + comments[i].commentEmail + "</a>&nbsp;&nbsp;"
                            + $.bowknot.getDate(comments[i].commentDate.time, 1)
                            + "&nbsp;</span><div class='clear'></div></div><div class='margin12'>"
                            + contentHTML + "</div>";
                        }
                        if ("" === commentsHTML) {
                            commentsHTML = Label.noCommentLabel;
                        }
                        $("#" + fromId + "Comments").html(commentsHTML);
                        break;
                    default:
                        break;
                };
                $("#loadMsg").text("");
            } catch (e) {}
        }, {
            "oId": articleId
        });
    },
    
    /*
     * 删除评论
     * @id 评论 id
     * @fromId 该评论来自文章/草稿/自定义页面
     */
    del: function (id, fromId, articleId) {
        var isDelete = confirm(Label.confirmRemoveLabel);
        if (isDelete) {
            $("#loadMsg").text(Label.loadingLabel);
            var from = "Article";
            if (fromId === "page") {
                from = "Page";
            }
            jsonRpc.commentService["removeCommentOf" + from](function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_COMMENT_FAIL_FORBIDDEN":
                            $("#tipMsg").text(Label.forbiddenLabel);
                            break;
                        case "REMOVE_COMMENT_SUCC":
                            admin.comment.getList(articleId, fromId);
                            $("#tipMsg").text(Label.removeSuccLabel);
                            break;
                        default:
                            $("#tipMsg").text("");
                            $("#loadMsg").text("");
                            break;
                    }
                } catch (e) {}
            }, {
                "oId": id
            });
        }
    }
};
/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * article list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.6, July 24, 2011
 */

/* article-list 相关操作 */
admin.articleList = {
    tablePagination:  new TablePaginate("article"),
    
    /* 
     * 初始化 table, pagination, comments dialog 
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            text: Label.titleLabel,
            index: "title",
            minWidth: 110,
            style: "padding-left: 12px;font-size:14px;"
        }, {
            text: Label.tagsLabel,
            index: "tags",
            width: 300,
            style: "padding-left: 12px;"
        }, {
            text: Label.authorLabel,
            index: "author",
            width: 150,
            style: "padding-left: 12px;"
        }, {
            text: Label.createDateLabel,
            index: "date",
            width: 150,
            style: "padding-left: 12px;"
        }, {
            text: Label.commentLabel,
            index: "comments",
            width: 80,
            style: "padding-left: 12px;"
        }, {
            text: Label.viewLabel,
            width: 80,
            index: "articleViewCount",
            style: "padding-left: 12px;"
        }]);
        this.tablePagination.initPagination();
        this.tablePagination.initCommentsDialog();
        this.getList(page);
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        var that = this;
        $("#loadMsg").text(Label.loadingLabel);
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE,
            "articleIsPublished": true
        };
        jsonRpc.articleService.getArticles(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_ARTICLES_SUCC":
                        var articles = result.articles,
                        articleData = [];
                        for (var i = 0; i < articles.length; i++) {
                            articleData[i] = {};
                            articleData[i].tags = articles[i].articleTags;
                            articleData[i].title = "<a href='" + articles[i].articlePermalink + "' target='_blank' title='" + articles[i].articleTitle + "' class='no-underline'>"
                            + articles[i].articleTitle + "</a>";
                            articleData[i].date = $.bowknot.getDate(articles[i].articleCreateDate.time, 1);
                            articleData[i].comments = articles[i].articleCommentCount;
                            articleData[i].articleViewCount = articles[i].articleViewCount;
                            articleData[i].author = articles[i].authorName;
                            
                            var topClass = articles[i].articlePutTop ? Label.cancelPutTopLabel : Label.putTopLabel;
                            articleData[i].expendRow = "<a target='_blank' href='" + articles[i].articlePermalink + "'>" + Label.viewLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.article.get('" + articles[i].oId + "', true)\">" + Label.updateLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.article.del('" + articles[i].oId + "', 'article')\">" + Label.removeLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.articleList.popTop(this, '" + articles[i].oId + "')\">" + topClass + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.comment.open('" + articles[i].oId + "', 'article')\">" + Label.commentLabel + "</a>";
                        }
                    
                        that.tablePagination.updateTablePagination(articleData, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },

    /* 
     * 制定或者取消置顶 
     * @it 触发事件的元素本身
     * @id 草稿 id
     */
    popTop: function (it, id) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#tipMsg").text("");
        var requestJSONObject = {
            "oId": id
        };
        var $it = $(it);
        if ($it.html() === Label.putTopLabel) {
            jsonRpc.articleService.putTopArticle(function (result, error) {
                try {
                    switch (result.sc) {
                        case "PUT_TOP_ARTICLE_SUCC":
                            $it.html(Label.cancelPutTopLabel);
                            $("#tipMsg").text(Label.putTopSuccLabel);
                            break;
                        case "PUT_TOP_ARTICLE_FAIL_":
                            $("#tipMsg").text(Label.putTopFailLabel);
                            break;
                        case "PUT_TOP_ARTICLE_FAIL_FORBIDDEN":
                            $("#tipMsg").text(Label.forbiddenLabel);
                            break;
                        default:
                            $("#tipMsg").text("");
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        } else {
            jsonRpc.articleService.cancelTopArticle(function (result, error) {
                try {
                    switch (result.sc) {
                        case "CANCEL_TOP_ARTICLE_SUCC":
                            $it.html(Label.putTopLabel);
                            $("#tipMsg").text(Label.cancelTopSuccLabel);
                            break;
                        case "CANCEL_TOP_ARTICLE_FAIL_":
                            $("#tipMsg").text(Label.cancelTopFailLabel);
                            break;
                        case "CANCEL_TOP_ARTICLE_FAIL_FORBIDDEN":
                            $("#tipMsg").text(Label.forbiddenLabel);
                            break;
                        default:
                            $("#tipMsg").text("");
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["article-list"] =  {
    "obj": admin.articleList,
    "init": admin.articleList.init,
    "refresh": admin.articleList.getList
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * draft list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.7, Aug 19, 2011
 */

/* draft-list 相关操作 */
admin.draftList = {
    tablePagination:  new TablePaginate("draft"),
    
    /* 
     * 初始化 table, pagination, comments dialog 
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            text: Label.titleLabel,
            index: "title",
            minWidth: 110,
            style: "padding-left: 12px;font-size:14px;"
        }, {
            text: Label.tagsLabel,
            index: "tags",
            width: 350,
            style: "padding-left: 12px;"
        }, {
            text: Label.authorLabel,
            index: "author",
            width: 150,
            style: "padding-left: 12px;"
        }, {
            text: Label.createDateLabel,
            index: "date",
            width: 150,
            style: "padding-left: 12px;"
        }, {
            text: Label.commentLabel,
            index: "comments",
            width: 80,
            style: "padding-left: 12px;"
        }, {
            text: Label.viewLabel,
            width: 80,
            index: "articleViewCount",
            style: "padding-left: 12px;"
        }]);
        this.tablePagination.initPagination();
        this.tablePagination.initCommentsDialog();
        this.getList(page);
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        $("#loadMsg").text(Label.loadingLabel);
        var that = this;
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE,
            "articleIsPublished": false
        };
        jsonRpc.articleService.getArticles(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_ARTICLES_SUCC":
                        var articles = result.articles,
                        articleData = [];
                        for (var i = 0; i < articles.length; i++) {
                            articleData[i] = {};
                            articleData[i].tags = articles[i].articleTags;
                            articleData[i].date = $.bowknot.getDate(articles[i].articleCreateDate.time, 1);
                            articleData[i].comments = articles[i].articleCommentCount;
                            articleData[i].articleViewCount = articles[i].articleViewCount;
                            articleData[i].author = articles[i].authorName;
                            articleData[i].title = "<a class='no-underline' href='" + articles[i].articlePermalink + "' target='_blank'>" + articles[i].articleTitle + "</a>";
                            articleData[i].expendRow = "<a target='_blank' href='" + articles[i].articlePermalink + "'>" + Label.viewLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.article.get('" + articles[i].oId + "', false);\">" + Label.updateLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.article.del('" + articles[i].oId + "', 'draft')\">" + Label.removeLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.comment.open('" + articles[i].oId + "', 'draft')\">" + Label.commentLabel + "</a>";
                        }
                    
                        that.tablePagination.updateTablePagination(articleData, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["draft-list"] =  {
    "obj": admin.draftList,
    "init": admin.draftList.init,
    "refresh": admin.draftList.getList
};/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * file list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.6, Aug 19, 2011
 */

/* file-list 相关操作 */
admin.fileList = {
    tablePagination:  new TablePaginate("file"),
    
    pageInfo: {
        currentCount: 1,
        pageCount: 1,
        currentPage: 1
    },
    
    /* 
     * 初始化 table, pagination 
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            style: "padding-left: 12px;font-size:14px;",
            text: Label.fileNameLabel,
            index: "name",
            minWidth: 260
        }, {
            text: Label.uploadDateLabel,
            index: "uploadDate",
            width: 200,
            style: "padding-left: 12px;"
        }, {
            text: Label.sizeLabel + " (Bytes)",
            index: "size",
            width: 150,
            style: "padding-left: 12px;"
        }, {
            text: Label.downloadCountLabel,
            index: "downloadCnt",
            width: 80,
            style: "padding-left: 12px;"
        }]);
        this.tablePagination.initPagination();
        this.getList(page);
        
        $("#formActionHidden").load(function () {
            admin.fileList.getList(1);
            var $iframe = $("#formActionHidden").contents();
            var tip = $iframe.find("pre").html();
            if (tip === "") {
                tip = Label.addSuccLabel; 
                $("#uploadFile").html("<input type='file' name='myFile' size='45'>");
            }
            $("#tipMsg").html(tip);
        });
    },

    /*
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        $("#loadMsg").text(Label.loadingLabel);
        var that = this;
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE
        };
        this.pageInfo.currentPage = pageNum;
        var result = jsonRpc.fileService.getFiles(requestJSONObject);
        switch (result.sc) {
            case "GET_FILES_SUCC":
                var files = result.files;
                var fileData = [];
                admin.fileList.pageInfo.currentCount = files.length;
                admin.fileList.pageInfo.pageCount = result.pagination.paginationPageCount;
                for (var i = 0; i < files.length; i++) {
                    fileData[i] = {};
                    fileData[i].name = "<a class='no-underline' href='" + files[i].fileDownloadURL + "'>"
                    + files[i].fileName + "</a>";
                    fileData[i].uploadDate = $.bowknot.getDate(files[i].fileUploadDate.time, 1);
                    fileData[i].downloadCnt = files[i].fileDownloadCount;
                    fileData[i].size = files[i].fileSize;
                    fileData[i].expendRow = "<a href='" + files[i].fileDownloadURL + "'>" + Label.downloadLabel + "</a>  \
                        <a href='javascript:void(0)' onclick=\"admin.fileList.del('" + files[i].oId + "')\">" + Label.removeLabel + "</a>";
                }

                that.tablePagination.updateTablePagination(fileData, pageNum, result.pagination);
                break;
            default:
                break;
        }
        $("#loadMsg").text("");
    },

    /* 
     * 删除文件
     * @id 文件 id 
     */
    del: function (id) {
        var isDelete = confirm(Label.confirmRemoveLabel);
        if (isDelete) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "oId": id
            };

            jsonRpc.fileService.removeFile(function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_FILE_SUCC":
                            var pageNum = admin.fileList.pageInfo.currentPage;
                            if (admin.fileList.pageInfo.currentCount === 1 && admin.fileList.pageInfo.pageCount !== 1 &&
                                admin.fileList.pageInfo.currentPage === admin.fileList.pageInfo.pageCount) {
                                admin.fileList.pageInfo.pageCount--;
                                pageNum = admin.fileList.pageInfo.pageCount;
                            }
                            var hashList = window.location.hash.split("/");
                            if (pageNum !== parseInt(hashList[hashList.length - 1])) {
                                admin.setHashByPage(pageNum);
                            }
                            admin.fileList.getList(pageNum);
                            $("#tipMsg").text(Label.removeSuccLabel);
                            break;
                        case "REMOVE_FILE_FAIL_":
                            $("#tipMsg").text(Label.removeFailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["file-list"] =  {
    "obj": admin.fileList,
    "init": admin.fileList.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * page list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.7, Aug 6, 2011
 */

/* page-list 相关操作 */
admin.pageList = {
    tablePagination:  new TablePaginate("page"),
    pageInfo: {
        currentCount: 1,
        pageCount: 1,
        currentPage: 1
    },
    id: "",
    
    /* 
     * 初始化 table, pagination, comments dialog
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            text: "",
            index: "pageOrder",
            width: 60,
            style: "padding-left: 12px;font-size:14px;"
        }, {
            style: "padding-left: 12px;",
            text: Label.titleLabel,
            index: "pageTitle",
            width: 300
        }, {
            style: "padding-left: 12px;",
            text: Label.permalinkLabel,
            index: "pagePermalink",
            minWidth: 300
        }, {
            text: Label.commentLabel,
            index: "comments",
            width: 80,
            style: "padding-left: 12px;"
        }]);
        this.tablePagination.initPagination();
        this.tablePagination.initCommentsDialog();
        this.getList(page);
        
        var language = Label.localeString.substring(0, 2);
        if (language === "zh") {
            language = "zh-cn";
        }
        tinyMCE.init({
            // General options
            language: language,
            mode : "exact",
            elements : "pageContent",
            theme : "advanced",
            plugins : "autosave,style,advhr,advimage,advlink,preview,media,paste,fullscreen,syntaxhl,inlinepopups",

            // Theme options
            theme_advanced_buttons1 : "forecolor,backcolor,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,formatselect,fontselect,fontsizeselect",
            theme_advanced_buttons2 : "bullist,numlist,outdent,indent,|,undo,redo,|,sub,sup,blockquote,charmap,image,iespell,media,|,advhr,link,unlink,anchor,cleanup,|,pastetext,pasteword,code,preview,fullscreen,syntaxhl",
            theme_advanced_buttons3 : "",
            theme_advanced_toolbar_location : "top",
            theme_advanced_toolbar_align : "left",
            theme_advanced_resizing : true,

            extended_valid_elements: "pre[name|class],iframe[src|width|height|name|align]",

            relative_urls: false,
            remove_script_host: false
        });
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        $("#loadMsg").text(Label.loadingLabel);
        var that = this;
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE
        };
        this.pageInfo.currentPage = pageNum;
        
        jsonRpc.pageService.getPages(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_PAGES_SUCC":
                        var pages = result.pages;
                        var pageData = [];
                        admin.pageList.pageInfo.currentCount = pages.length;
                        admin.pageList.pageInfo.pageCount = result.pagination.paginationPageCount === 0 ? 1 : result.pagination.paginationPageCount;
                        for (var i = 0; i < pages.length; i++) {
                            pageData[i] = {};
                            if (i === 0) {
                                if (pages.length === 1) {
                                    pageData[i].pageOrder = "";
                                } else {
                                    pageData[i].pageOrder = '<div class="table-center" style="width:14px">\
                                        <span onclick="admin.pageList.changeOrder(' + pages[i].oId + ', ' + i + ', \'down\');" \
                                        class="table-downIcon"></span></div>';
                                }
                            } else if (i === pages.length - 1) {
                                pageData[i].pageOrder = '<div class="table-center" style="width:14px">\
                                    <span onclick="admin.pageList.changeOrder(' + pages[i].oId + ', ' + i + ', \'up\');" class="table-upIcon"></span>\
                                    </div>';
                            } else {
                                pageData[i].pageOrder = '<div class="table-center" style="width:38px">\
                                    <span onclick="admin.pageList.changeOrder(' + pages[i].oId + ', ' + i + ', \'up\');" class="table-upIcon"></span>\
                                    <span onclick="admin.pageList.changeOrder(' + pages[i].oId + ', ' + i + ', \'down\');" class="table-downIcon"></span>\
                                    </div>';
                            }
                            
                            pageData[i].pageTitle = "<a class='no-underline' href='" + pages[i].pagePermalink + "' target='_blank'>" +
                            pages[i].pageTitle + "</a>";
                            pageData[i].pagePermalink = "<a class='no-underline' href='" + pages[i].pagePermalink + "' target='_blank'>"
                            + pages[i].pagePermalink + "</a>";
                            pageData[i].comments = pages[i].pageCommentCount;
                            pageData[i].expendRow = "<span><a href='" + pages[i].pagePermalink + "' target='_blank'>" + Label.viewLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.pageList.get('" + pages[i].oId + "')\">" + Label.updateLabel + "</a>\
                                <a href='javascript:void(0)' onclick=\"admin.pageList.del('" + pages[i].oId + "')\">" + Label.removeLabel + "</a>\
                                <a href='javascript:void(0)' onclick=\"admin.comment.open('" + pages[i].oId + "', 'page')\">" + Label.commentLabel + "</a></span>";
                        }
                        
                        that.tablePagination.updateTablePagination(pageData, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {}
        }, requestJSONObject);
    },
    
    /*
     * 获取自定义页面
     * @id 自定义页面 id
     */
    get: function (id) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#tipMsg").text("");
        var requestJSONObject = {
            "oId": id
        };

        jsonRpc.pageService.getPage(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_PAGE_SUCC":
                        admin.pageList.id = id;
                        tinyMCE.get('pageContent').setContent(result.page.pageContent);
                        $("#pagePermalink").val(result.page.pagePermalink);
                        $("#pageTitle").val(result.page.pageTitle);
                        $("#tipMsg").text(Label.getSuccLabel);
                        break;
                    case "GET_PAGE_FAIL_":
                        $("#tipMsg").text(Label.getFailLabels);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {}
        }, requestJSONObject);
    },

    /* 
     * 删除自定义页面
     * @id 自定义页面 id
     */
    del: function (id) {
        var isDelete = confirm(Label.confirmRemoveLabel);
        if (isDelete) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "oId": id
            };

            jsonRpc.pageService.removePage(function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_PAGE_SUCC":
                            var pageNum = admin.pageList.pageInfo.currentPage;
                            if (admin.pageList.pageInfo.currentCount === 1 && admin.pageList.pageInfo.pageCount !== 1 &&
                                admin.pageList.pageInfo.currentPage === admin.pageList.pageInfo.pageCount) {
                                admin.pageList.pageInfo.pageCount--;
                                pageNum = admin.pageList.pageInfo.pageCount;
                            }
                            var hashList = window.location.hash.split("/");
                            if (pageNum == hashList[hashList.length - 1]) {
                                admin.pageList.getList(pageNum);
                            } else {
                                admin.setHashByPage(pageNum);
                            }
                            $("#tipMsg").text(Label.removeSuccLabel);
                            break;
                        case "REMOVE_PAGE_FAIL_":
                            $("#tipMsg").text(Label.removeFailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    },
    
    /*
     * 添加自定义页面
     */
    add: function () {
        if (this.validate()) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "page": {
                    "pageTitle": $("#pageTitle").val(),
                    "pageContent": tinyMCE.get('pageContent').getContent(),
                    "pagePermalink": $("#pagePermalink").val()
                }
            };
            jsonRpc.pageService.addPage(function (result, error) {
                try {
                    switch (result.sc) {
                        case "ADD_PAGE_FAIL_DUPLICATED_PERMALINK":
                            var msg = Label.addFailLabel + ", " + Label.duplicatedPermalinkLabel;
                            $("#tipMsg").text(msg);
                            break;
                        case "ADD_PAGE_FAIL_INVALID_PERMALINK_FORMAT":
                            msg = Label.addFailLabel + ", " + Label.invalidPermalinkFormatLabel;
                            $("#tipMsg").text(msg);
                            break;
                        case "ADD_PAGE_SUCC":
                            admin.pageList.id = "";
                            $("#pagePermalink").val("");
                            $("#pageTitle").val("");
                            if (tinyMCE.get("pageContent")) {
                                tinyMCE.get('pageContent').setContent("");
                            } else {
                                $("#pageContent").val("");
                            }
                            
                            if (admin.pageList.pageInfo.currentCount === Label.PAGE_SIZE &&
                                admin.pageList.pageInfo.currentPage === admin.pageList.pageInfo.pageCount) {
                                admin.pageList.pageInfo.pageCount++;
                            }
                            var hashList = window.location.hash.split("/");
                            if (admin.pageList.pageInfo.pageCount == hashList[hashList.length - 1]) {
                                admin.pageList.getList(admin.pageList.pageInfo.pageCount);
                            } else {
                                admin.setHashByPage(admin.pageList.pageInfo.pageCount);
                            }
                            $("#tipMsg").text(Label.addSuccLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    },
    
    /*
     * 跟新自定义页面
     */
    update: function () {
        if (this.validate()) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "page": {
                    "pageTitle": $("#pageTitle").val(),
                    "oId": this.id,
                    "pageContent": tinyMCE.get('pageContent').getContent(),
                    "pagePermalink": $("#pagePermalink").val()
                }
            };
            jsonRpc.pageService.updatePage(function (result, error) {
                try {
                    switch (result.sc) {
                        case "UPDATE_PAGE_FAIL_DUPLICATED_PERMALINK":
                            var msg = Label.addFailLabel + ", " + Label.duplicatedPermalinkLabel;
                            $("#tipMsg").text(msg);
                            break;
                        case "UPDATE_PAGE_SUCC":
                            admin.pageList.getList(admin.pageList.pageInfo.currentPage);
                            admin.pageList.id = "";
                            $("#tipMsg").text(Label.updateSuccLabel);
                            $("#pageTitle").val("");
                            tinyMCE.get('pageContent').setContent("");
                            $("#pagePermalink").val("");
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    },
    
    /*
     * 验证字段
     */
    validate: function () {
        if ($("#pageTitle").val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.titleEmptyLabel);
            $("#pageTitle").focus();
        } else if (tinyMCE.get('pageContent').getContent().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.contentEmptyLabel);
        } else {
            return true;
        }
        return false;
    },
    
    /*
     * 提交自定义页面
     */
    submit: function () {
        if (this.id !== "") {
            this.update();
        } else {
            this.add();
        }
    },
    
    /*
     * 调换顺序
     */
    changeOrder: function (id, order, status) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#tipMsg").text("");
        var srcOrder = order;
        if (status === "up") {
            srcOrder -= 1;
        } else {
            srcOrder += 1;
        }

        jsonRpc.pageService.changeOrder(function (result, error) {
            try {
                if (result) {
                    admin.pageList.getList(admin.pageList.pageInfo.currentPage);
                } else {
                    $("#tipMsg").text(Label.updateFailLabel);
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, id.toString(), srcOrder);
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["page-list"] =  {
    "obj": admin.pageList,
    "init": admin.pageList.init,
    "refresh": admin.pageList.getList
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * others for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.4, Aug 19, 2011
 */

/* oterhs 相关操作 */
admin.others = {
    /*
     * 移除未使用的 tag
     */
    removeUnusedTags: function () {
        $("#tipMsg").text("");
        jsonRpc.tagService.removeUnusedTags(function (result, error) {
            try {
                if (result.sc === "REMOVE_UNUSED_TAGS_SUCC") {
                    $("#tipMsg").text(Label.removeSuccLabel);
                } else {
                    $("#tipMsg").text(Label.removeFailLabel);
                }
            } catch (e) {
            }
        });
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register.others =  {
    "obj": admin.others,
    "init": function () {
        $("#loadMsg").text("");
    },
    "refresh": function () {
        $("#loadMsg").text("");
    }
}
/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * link list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.7, Aug 19, 2011
 */

/* link-list 相关操作 */
admin.linkList = {
    tablePagination:  new TablePaginate("link"),
    pageInfo: {
        currentCount: 1,
        pageCount: 1,
        currentPage: 1
    },
    id: "",
    
    /* 
     * 初始化 table, pagination
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            text: "",
            index: "linkOrder",
            width: 60
        },{
            style: "padding-left: 12px;",
            text: Label.linkTitleLabel,
            index: "linkTitle",
            width: 230
        }, {
            style: "padding-left: 12px;",
            text: Label.urlLabel,
            index: "linkAddress",
            minWidth: 180
        }]);
    
        this.tablePagination.initPagination();
        this.getList(page);
        
        $("#updateLink").dialog({
            width: 700,
            height: 160,
            "modal": true,
            "hideFooter": true
        });
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        $("#loadMsg").text(Label.loadingLabel);
        if (pageNum === 0) {
            pageNum = 1;
        }
        this.pageInfo.currentPage = pageNum;
        var that = this;
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE
        };
        jsonRpc.linkService.getLinks(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_LINKS_SUCC":
                        var links = result.links;
                        var linkData = [];
                        admin.linkList.pageInfo.currentCount = links.length;
                        admin.linkList.pageInfo.pageCount = result.pagination.paginationPageCount === 0 ? 1 : result.pagination.paginationPageCount;

                        for (var i = 0; i < links.length; i++) {
                            linkData[i] = {};
                            if (i === 0) {
                                if (links.length === 1) {
                                    linkData[i].linkOrder = "";
                                } else {
                                    linkData[i].linkOrder = '<div class="table-center" style="width:14px">\
                                <span onclick="admin.linkList.changeOrder(' + links[i].oId + ', ' + i + ', \'down\');" class="table-downIcon"></span>\
                            </div>';
                                }
                            } else if (i === links.length - 1) {
                                linkData[i].linkOrder = '<div class="table-center" style="width:14px">\
                                <span onclick="admin.linkList.changeOrder(' + links[i].oId + ', ' + i + ', \'up\');" class="table-upIcon"></span>\
                            </div>';
                            } else {
                                linkData[i].linkOrder = '<div class="table-center" style="width:38px">\
                                <span onclick="admin.linkList.changeOrder(' + links[i].oId + ', ' + i + ', \'up\');" class="table-upIcon"></span>\
                                <span onclick="admin.linkList.changeOrder(' + links[i].oId + ', ' + i + ', \'down\');" class="table-downIcon"></span>\
                            </div>';
                            }
                            linkData[i].linkTitle = links[i].linkTitle;
                            linkData[i].linkAddress = "<a target='_blank' class='no-underline' href='" + links[i].linkAddress + "'>"
                            + links[i].linkAddress + "</a>";
                            linkData[i].expendRow = "<span><a href='" + links[i].linkAddress + "' target='_blank'>" + Label.viewLabel + "</a>  \
                                <a href='javascript:void(0)' onclick=\"admin.linkList.get('" + links[i].oId + "')\">" + Label.updateLabel + "</a>\
                                <a href='javascript:void(0)' onclick=\"admin.linkList.del('" + links[i].oId + "')\">" + Label.removeLabel + "</a></span>";
                        }

                        that.tablePagination.updateTablePagination(linkData, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },
    
    /*
     * 添加链接
     */
    add: function () {
        if (this.validate()) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "link": {
                    "linkTitle": $("#linkTitle").val(),
                    "linkAddress": $("#linkAddress").val()
                }
            };
            jsonRpc.linkService.addLink(function (result, error) {
                try {
                    switch (result.sc) {
                        case "ADD_LINK_SUCC":
                            $("#linkTitle").val("");
                            $("#linkAddress").val("");
                            if (admin.linkList.pageInfo.currentCount === Label.PAGE_SIZE &&
                                admin.linkList.pageInfo.currentPage === admin.linkList.pageInfo.pageCount) {
                                admin.linkList.pageInfo.pageCount++;
                            }
                            var hashList = window.location.hash.split("/");
                            if (admin.linkList.pageInfo.pageCount !== parseInt(hashList[hashList.length - 1])) {
                                admin.setHashByPage(admin.linkList.pageInfo.pageCount);
                            }
                            admin.linkList.getList(admin.linkList.pageInfo.pageCount);
                            $("#tipMsg").text(Label.addSuccLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    },
    
    /*
     * 获取链接
     * @id 链接 id
     */
    get: function (id) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#updateLink").dialog("open");
        var requestJSONObject = {
            "oId": id
        };

        jsonRpc.linkService.getLink(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_LINK_SUCC":
                        admin.linkList.id = id;
                        $("#linkTitleUpdate").val(result.link.linkTitle);
                        $("#linkAddressUpdate").val(result.link.linkAddress);
                        break;
                    case "GET_LINK_FAIL_":
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {}
        }, requestJSONObject);
    },
    
    /*
     * 跟新自定义页面
     */
    update: function () {
        if (this.validate("Update")) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "link": {
                    "linkTitle": $("#linkTitleUpdate").val(),
                    "oId": this.id,
                    "linkAddress": $("#linkAddressUpdate").val()
                }
            };
            jsonRpc.linkService.updateLink(function (result, error) {
                try {
                    switch (result.sc) {
                        case "UPDATE_LINK_SUCC":
                            $("#updateLink").dialog("close");
                            admin.linkList.getList(admin.linkList.pageInfo.currentPage);
                            $("#tipMsg").text(Label.updateSuccLabel);
                            break;
                        case "UPDATE_LINK_FAIL_":
                            $("#updateLink").dialog("close");
                            $("#tipMsg").text(Label.updateFailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    },
    
    /*
     * 删除链接
     * @id 链接 id
     */
    del: function (id) {
        var isDelete = confirm(Label.confirmRemoveLabel);
        if (isDelete) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "oId": id
            };

            jsonRpc.linkService.removeLink(function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_LINK_SUCC":
                            var pageNum = admin.linkList.pageInfo.currentPage;
                            if (admin.linkList.pageInfo.currentCount === 1 && admin.linkList.pageInfo.pageCount !== 1 &&
                                admin.linkList.pageInfo.currentPage === admin.linkList.pageInfo.pageCount) {
                                admin.linkList.pageInfo.pageCount--;
                                pageNum = admin.linkList.pageInfo.pageCount;
                            }
                            var hashList = window.location.hash.split("/");
                            if (pageNum !== parseInt(hashList[hashList.length - 1])) {
                                admin.setHashByPage(pageNum);
                            }
                            admin.linkList.getList(pageNum);
                            $("#tipMsg").text(Label.removeSuccLabel);
                            break;
                        case "REMOVE_LINK_FAIL_":
                            $("#tipMsg").text(Label.removeFailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    },
    
    /*
     * 验证字段
     * @status 更新或者添加时进行验证
     */
    validate: function (status) {
        if (!status) {
            status = "";
        }
        if ($("#linkTitle" + status).val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.titleEmptyLabel);
            $("#linkTitle" + status).focus().val("");
        } else if ($("#linkAddress" + status).val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.addressEmptyLabel);
            $("#linkAddress" + status).focus().val("");
        } else {
            return true;
        }
        return false;
    },
    
    /*
     * 调换顺序
     */
    changeOrder: function (id, order, status) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#tipMsg").text("");
        var srcOrder = order;
        if (status === "up") {
            srcOrder -= 1;
        } else {
            srcOrder += 1;
        }

        jsonRpc.linkService.changeOrder(function (result, error) {
            try {
                if (result) {
                    admin.linkList.getList(admin.linkList.pageInfo.currentPage);
                } else {
                    $("#tipMsg").text(Label.updateFailLabel);
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, id.toString(), srcOrder);
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["link-list"] =  {
    "obj": admin.linkList,
    "init": admin.linkList.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * preference for admin.
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @author <a href="mailto:DL88250@gmail.com">Liang Ding</a>
 * @version 1.0.0.8, Oct 2, 2011
 */

/* preference 相关操作 */
admin.preference = {
    locale: "",
    
    /*
     * 初始化
     */
    init: function () {
        $("#tabPreference").tabs();
         
        jsonRpc.preferenceService.getPreference(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_PREFERENCE_SUCC":
                        // preference
                        var preference = result.preference;
                        $("#metaKeywords").val(preference.metaKeywords),
                        $("#metaDescription").val(preference.metaDescription),
                        $("#blogTitle").val(preference.blogTitle),
                        $("#blogSubtitle").val(preference.blogSubtitle),
                        $("#mostCommentArticleDisplayCount").val(preference.mostCommentArticleDisplayCount);
                        $("#mostViewArticleDisplayCount").val(preference.mostViewArticleDisplayCount),
                        $("#recentCommentDisplayCount").val(preference.recentCommentDisplayCount);
                        $("#mostUsedTagDisplayCount").val(preference.mostUsedTagDisplayCount);
                        $("#articleListDisplayCount").val(preference.articleListDisplayCount);
                        $("#articleListPaginationWindowSize").val(preference.articleListPaginationWindowSize);
                        $("#blogHost").val(preference.blogHost);
                        $("#localeString").val(preference.localeString);
                        $("#timeZoneId").val(preference.timeZoneId);
                        $("#noticeBoard").val(preference.noticeBoard);
                        $("#htmlHead").val(preference.htmlHead);
                        $("#secret").val(preference.googleOAuthConsumerSecret);
                        $("#externalRelevantArticlesDisplayCount").val(preference.externalRelevantArticlesDisplayCount);
                        $("#relevantArticlesDisplayCount").val(preference.relevantArticlesDisplayCount);
                        $("#randomArticlesDisplayCount").val(preference.randomArticlesDisplayCount);
                        $("#keyOfSolo").val(preference.keyOfSolo);
                        preference.enableArticleUpdateHint ? $("#enableArticleUpdateHint").attr("checked", "checked") : $("#enableArticleUpdateHint").removeAttr("checked");
                        // Tencent micro blog settings
                        preference.enablePostToTencentMicroblog ? $("#postToTencentMicroblog").attr("checked", "checked") : $("#postToTencentMicroblog").removeAttr("checked");
                        $("#tencentMicroblogAppKey").val(preference.tencentMicroblogAppKey);
                        $("#tencentMicroblogAppSecret").val(preference.tencentMicroblogAppSecret);
                        
                        preference.allowVisitDraftViaPermalink ? $("#allowVisitDraftViaPermalink").attr("checked", "checked") : $("allowVisitDraftViaPermalink").removeAttr("checked");

                        admin.preference.locale = preference.localeString;

                        // skin
                        $("#skinMain").data("skinDirName", preference.skinDirName);
                        var skins = eval('(' + preference.skins + ')');
                        var skinsHTML = "";
                        for (var i = 0; i < skins.length; i++) {
                            if (skins[i].skinName === preference.skinName
                                && skins[i].skinDirName === preference.skinDirName ) {
                                skinsHTML += "<div title='" + skins[i].skinDirName
                                + "' class='left skinItem selected'><img class='skinPreview' src='skins/"
                                + skins[i].skinDirName + "/preview.png'/><div>" + skins[i].skinName + "</div></div>"
                            } else {
                                skinsHTML += "<div title='" + skins[i].skinDirName
                                + "' class='left skinItem'><img class='skinPreview' src='skins/"
                                + skins[i].skinDirName + "/preview.png'/><div>" + skins[i].skinName + "</div></div>"
                            }
                        }
                        $("#skinMain").append(skinsHTML + "<div class='clear'></div>");

                        $(".skinItem").click(function () {
                            $(".skinItem").removeClass("selected");
                            $(this).addClass("selected");
                            $("#skinMain").data("skinDirName", this.title);
                        });

                        // sign
                        var signs = eval('(' + preference.signs + ')');
                        for (var j = 1; j < signs.length; j++) {
                            $("#preferenceSign" + j).val(signs[j].signHTML);
                            $("#preferenceSignButton" + j).tip({
                                content: signs[j].signHTML === "" ? Label.signIsNullLabel : signs[j].signHTML.replace(/\n/g, "").replace(/<script.*<\/script>/ig, ""),
                                position: "bottom"
                            });
                        }
                        
                        // Article list style
                        $("#articleListDisplay").val(preference.articleListStyle);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        });
    },
    
    /*
     * 更新
     */
    update: function () {
        $("#loadMsg").text(Label.loadingLabel);
        $("#tipMsg").text("");
        if ($("#syncGoogle").hasClass("selected")) {
            if ("" === $("#secret").val().replace(/\s/g, "")) {
                $("#tipMsg").text(Label.contentEmptyLabel);
                return;
            }
        }

        var signs = [{
            "oId": 0,
            "signHTML": ""
        }, {
            "oId": 1,
            "signHTML": $("#preferenceSign1").val()
        }, {
            "oId": 2,
            "signHTML": $("#preferenceSign2").val()
        }, {
            "oId": 3,
            "signHTML": $("#preferenceSign3").val()
        }];
        
        var requestJSONObject = {
            "preference": {
                "metaKeywords": $("#metaKeywords").val(),
                "metaDescription": $("#metaDescription").val(),
                "blogTitle": $("#blogTitle").val(),
                "blogSubtitle": $("#blogSubtitle").val(),
                "mostCommentArticleDisplayCount": $("#mostCommentArticleDisplayCount").val(),
                "mostViewArticleDisplayCount": $("#mostViewArticleDisplayCount").val(),
                "recentArticleDisplayCount": 10, // XXX: remove recentArticleDisplayCount
                "recentCommentDisplayCount": $("#recentCommentDisplayCount").val(),
                "mostUsedTagDisplayCount": $("#mostUsedTagDisplayCount").val(),
                "articleListDisplayCount": $("#articleListDisplayCount").val(),
                "articleListPaginationWindowSize": $("#articleListPaginationWindowSize").val(),
                "skinDirName": $("#skinMain").data("skinDirName"),
                "blogHost": $("#blogHost").val(),
                "localeString": $("#localeString").val(),
                "timeZoneId": $("#timeZoneId").val(),
                "noticeBoard": $("#noticeBoard").val(),
                "htmlHead": $("#htmlHead").val(),
                "googleOAuthConsumerSecret": ""/*$("#secret").val()*/,
                "externalRelevantArticlesDisplayCount": $("#externalRelevantArticlesDisplayCount").val(),
                "relevantArticlesDisplayCount": $("#relevantArticlesDisplayCount").val(),
                "randomArticlesDisplayCount": $("#randomArticlesDisplayCount").val(),
                "enableArticleUpdateHint": $("#enableArticleUpdateHint").prop("checked"),
                "signs": signs,
                "tencentMicroblogAppKey": $("#tencentMicroblogAppKey").val(),
                "tencentMicroblogAppSecret": $("#tencentMicroblogAppSecret").val(),
                "enablePostToTencentMicroblog": $("#postToTencentMicroblog").prop("checked"),
                "keyOfSolo": $("#keyOfSolo").val(),
                "allowVisitDraftViaPermalink": $("#allowVisitDraftViaPermalink").prop("checked"),
                "articleListStyle": $("#articleListDisplay").val()
            }
        }
        
        jsonRpc.preferenceService.updatePreference(function (result, error) {
            try {
                switch (result.sc) {
                    case "UPDATE_PREFERENCE_SUCC":
                        $("#tipMsg").text(Label.updateSuccLabel);
                        if ($("#localeString").val() !== admin.preference.locale) {
                            window.location.reload();
                        }
                        
                        // update article and preferences signs
                        for (var i = 1; i < signs.length; i++) {
                            if ($("#articleSign" + signs[i].oId).length === 1) {
                                $("#articleSign" + signs[i].oId).tip("option", "content", 
                                    signs[i].signHTML === "" ? Label.signIsNullLabel : signs[i].signHTML.replace(/\n/g, "").replace(/<script.*<\/script>/ig, ""));
                            }
                            $("#preferenceSignButton" + signs[i].oId).tip("option", "content", 
                                signs[i].signHTML === "" ? Label.signIsNullLabel : signs[i].signHTML.replace(/\n/g, "").replace(/<script.*<\/script>/ig, ""));
                        }
                        break;
                    case "UPDATE_PREFERENCE_FAIL_":
                        $("#tipMsg").text(Label.updatePreferenceFailLabel);
                        break;
                    case "UPDATE_PREFERENCE_FAIL_CANNT_BE_LOCALHOST":
                        $("#tipMsg").text(Label.canntBeLocalhostOnProductionLabel);
                        break;
                    case "UPDATE_PREFERENCE_FAIL_NEED_MUL_USERS":
                        $("#tipMsg").text(Label.updatePreferenceFailNeedMulUsersLabel);
                        break;
                    default:
                        break;
                } 
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },
    
    /*
     * 腾讯微博认证
     */
    oauthTencent: function () {
        if ("" === $("#tencentMicroblogAppKey").val().replace(/\s/g, "")) {
            $("#tipMsg").text(Label.contentEmptyLabel);
            return;
        }

        if ("" === $("#tencentMicroblogAppSecret").val().replace(/\s/g, "")) {
            $("#tipMsg").text(Label.contentEmptyLabel);
            return;
        }

        $("#loadMsg").text(Label.loadingLabel);
        window.location = "tencent-microblog-oauth-authorize-token.do?appKey="
        + $("#tencentMicroblogAppKey").val()
        + "&appSecret=" + $("#tencentMicroblogAppSecret").val();

    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["preference"] =  {
    "obj": admin.preference,
    "init": admin.preference.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * plugin list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.9, Aug 24, 2011
 */

/* plugin-list 相关操作 */
admin.pluginList = {
    tablePagination:  new TablePaginate("plugin"),
    pageInfo: {
        currentCount: 1,
        pageCount: 1,
        currentPage: 1
    },
    /* 
     * 初始化 table, pagination
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            style: "padding-left: 12px;",
            text: Label.pluginNameLabel,
            index: "name",
            width: 230
        }, {
            style: "padding-left: 12px;",
            text: Label.statusLabel,
            index: "status",
            minWidth: 180
        }, {
            style: "padding-left: 12px;",
            text: Label.authorLabel,
            index: "author",
            width: 200
        }, {
            style: "padding-left: 12px;",
            text: Label.versionLabel,
            index: "version",
            width: 120
        }]);
    
        this.tablePagination.initPagination();
        this.getList(page);
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        $("#loadMsg").text(Label.loadingLabel);
        var that = this;
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE
        };
        jsonRpc.pluginService.getPlugins(function (result, error) {
            try {
                if (!result) {
                     $("#loadMsg").text("");
                    return;
                }
                switch (result.sc) {
                    case "GET_PLUGINS_SUCC":
                        admin.pluginList.pageInfo.currentPage = pageNum;
                        var datas = result.plugins;
                        for (var i = 0; i < datas.length; i++) {
                            datas[i].expendRow = "<a href='javascript:void(0)' onclick=\"admin.pluginList.changeStatus('" + 
                            datas[i].oId + "', '" + datas[i].status + "')\">";
                            if (datas[i].status === "ENABLED") {
                                datas[i].status = Label.enabledLabel;
                                datas[i].expendRow += Label.disableLabel;
                            } else {
                                datas[i].status = Label.disabledLabel;
                                datas[i].expendRow += Label.enableLabel;
                            }
                            datas[i].expendRow += "</a>";
                        }
                        that.tablePagination.updateTablePagination(result.plugins, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },
    
    changeStatus: function (pluginId, status) {
        if (status === "ENABLED") {
            status = "DISABLED";
        } else {
            status = "ENABLED";
        }
        jsonRpc.pluginService.setPluginStatus(function () {
            //admin.pluginList.getList(admin.pluginList.pageInfo.currentPage);
            $("#tipMsg").text(Label.updateSuccLabel);
            window.location.reload();
        }, pluginId, status);
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["plugin-list"] =  {
    "obj": admin.pluginList,
    "init": admin.pluginList.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * user list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.7, Sep 30, 2011
 */

/* user-list 相关操作 */
admin.userList = {
    tablePagination:  new TablePaginate("user"),
    pageInfo: {
        currentCount: 1,
        pageCount: 1,
        currentPage: 1
    },
    userInfo: {
        'oId': "",
        "userRole": ""
    },
    
    /* 
     * 初始化 table, pagination
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            style: "padding-left: 12px;",
            text: Label.commentNameLabel,
            index: "userName",
            width: 230
        }, {
            style: "padding-left: 12px;",
            text: Label.commentEmailLabel,
            index: "userEmail",
            minWidth: 180
        }, {
            style: "padding-left: 12px;",
            text: Label.administratorLabel,
            index: "isAdmin",
            width: 120
        }]);
    
        this.tablePagination.initPagination();
        this.getList(page);
        
        $("#userUpdate").dialog({
            width: 700,
            height: 190,
            "modal": true,
            "hideFooter": true
        });
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        $("#loadMsg").text(Label.loadingLabel);
        this.pageInfo.currentPage = pageNum;
        var that = this;
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE
        };
        jsonRpc.adminService.getUsers(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_USERS_SUCC":
                        var users = result.users;
                        var userData = [];
                        admin.userList.pageInfo.currentCount = users.length;
                        admin.userList.pageInfo.pageCount = result.pagination.paginationPageCount;
                        if (users.length < 1) {
                            alert("No user\n " + Label.reportIssueLabel);
                            $("#loadMsg").text("");
                            return;
                        }
                    
                        for (var i = 0; i < users.length; i++) {
                            userData[i] = {};
                            userData[i].userName = users[i].userName;
                            userData[i].userEmail = users[i].userEmail;
                            
                            if ("adminRole" === users[i].userRole) {
                                userData[i].isAdmin = "&nbsp;" + Label.administratorLabel;
                                userData[i].expendRow = "<a href='javascript:void(0)' onclick=\"admin.userList.get('" + 
                                users[i].oId + "', '" + users[i].userRole + "')\">" + Label.updateLabel + "</a>";
                            } else {
                                userData[i].expendRow = "<a href='javascript:void(0)' onclick=\"admin.userList.get('" + 
                                users[i].oId + "', '" + users[i].userRole + "')\">" + Label.updateLabel + "</a>\
                                <a href='javascript:void(0)' onclick=\"admin.userList.del('" + users[i].oId + "')\">" + Label.removeLabel + "</a>";
                                userData[i].isAdmin = Label.commonUserLabel;
                            }
                            
                        }
                        
                        that.tablePagination.updateTablePagination(userData, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },
    
    /*
     * 添加用户
     */
    add: function () {
        if (this.validate()) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "userName": $("#userName").val(),
                "userEmail": $("#userEmail").val(),
                "userPassword": $("#userPassword").val()
            };
            jsonRpc.adminService.addUser(function (result, error) {
                try {
                    switch (result.sc) {
                        case "ADD_USER_SUCC":
                            $("#userName").val("");
                            $("#userEmail").val("");
                            $("#userPassword").val("");
                            if (admin.userList.pageInfo.currentCount === Label.PAGE_SIZE &&
                                admin.userList.pageInfo.currentPage === admin.userList.pageInfo.pageCount) {
                                admin.userList.pageInfo.pageCount++;
                            }
                            var hashList = window.location.hash.split("/");
                            if (admin.userList.pageInfo.pageCount !== parseInt(hashList[hashList.length - 1])) {
                                admin.setHashByPage(admin.userList.pageInfo.pageCount);
                            }
                            admin.userList.getList(admin.userList.pageInfo.pageCount);
                            $("#tipMsg").text(Label.addSuccLabel);
                            break;
                        case "ADD_USER_FAIL_DUPLICATED_EMAIL":
                            $("#tipMsg").text(Label.duplicatedEmailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    },
    
    /*
     * 获取用户
     * @id 用户 id
     */
    get: function (id, userRole) {
        $("#loadMsg").text(Label.loadingLabel);
        $("#userUpdate").dialog("open");
        var requestJSONObject = {
            "oId": id
        };

        jsonRpc.adminService.getUser(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_USER_SUCC":
                        var $userEmailUpdate = $("#userEmailUpdate");
                        $("#userNameUpdate").val(result.user.userName).data("userInfo", {
                            'oId': id,
                            "userRole": userRole
                        });
                        $userEmailUpdate.val(result.user.userEmail);
                        if ("adminRole" === userRole) {
                            $userEmailUpdate.attr("disabled", "disabled");
                        } else {
                            $userEmailUpdate.removeAttr("disabled");
                        }
                        $("#userPasswordUpdate").val(result.user.userPassword);
                        break;
                    case "GET_USER_FAIL_":
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {}
        }, requestJSONObject);
    },
    
    /*
     * 更新用户
     */
    update: function () {
        if (this.validate("Update")) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var userInfo = $("#userNameUpdate").data("userInfo");
            var requestJSONObject = {
                "userName": $("#userNameUpdate").val(),
                "oId": userInfo.oId,
                "userEmail": $("#userEmailUpdate").val(),
                "userRole": userInfo.userRole,
                "userPassword": $("#userPasswordUpdate").val()
            };
            jsonRpc.adminService.updateUser(function (result, error) {
                try {
                    switch (result.sc) {
                        case "UPDATE_USER_SUCC":
                            admin.userList.getList(admin.userList.pageInfo.currentPage);
                            $("#tipMsg").text(Label.updateSuccLabel);
                            $("#userUpdate").dialog("close");
                            break;
                        case "UPDATE_USER_FAIL_DUPLICATED_EMAIL":
                            $("#tipMsg").text(Label.duplicatedEmailLabel);
                            break;
                        case "UPDATE_USER_FAIL_":
                            $("#tipMsg").text(Label.updateFailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {}
            }, requestJSONObject);
        }
    },
    
    /*
     * 删除用户
     * @id 用户 id
     */
    del: function (id) {
        var isDelete = confirm(Label.confirmRemoveLabel);
        if (isDelete) {
            $("#loadMsg").text(Label.loadingLabel);
            $("#tipMsg").text("");
            var requestJSONObject = {
                "oId": id
            };

            jsonRpc.adminService.removeUser(function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_USER_SUCC":
                            var pageNum = admin.userList.pageInfo.currentPage;
                            if (admin.userList.pageInfo.currentCount === 1 && admin.userList.pageInfo.pageCount !== 1 &&
                                admin.userList.pageInfo.currentPage === admin.userList.pageInfo.pageCount) {
                                admin.userList.pageInfo.pageCount--;
                                pageNum = admin.userList.pageInfo.pageCount;
                            }
                            var hashList = window.location.hash.split("/");
                            if (pageNum !== parseInt(hashList[hashList.length - 1])) {
                                admin.setHashByPage(pageNum);
                            }
                            admin.userList.getList(pageNum);
                            $("#tipMsg").text(Label.removeSuccLabel);
                            break;
                        case "REMOVE_USER_FAIL_SKIN_NEED_MUL_USERS":
                            $("#tipMsg").text(Label.removeUserFailSkinNeedMulUsersLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text("");
                } catch (e) {
                    console.error(e);
                }
            }, requestJSONObject);
        }
    },
    
    /*
     * 验证字段
     * @status 更新或者添加时进行验证
     */
    validate: function (status) {
        if (!status) {
            status = "";
        }

        if ($("#userName" + status).val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.nameEmptyLabel);
            $("#userName" + status).focus();
        }else if ($("#userEmail" + status).val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.mailCannotEmptyLabel);
            $("#userEmail" + status).focus();
        } else if(!/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test($("#userEmail" + status).val())) {
            $("#tipMsg").text(Label.mailInvalidLabel);
            $("#userEmail" + status).focus();
        } else if ($("#userPassword" + status).val().replace(/\s/g, "") === "") {
            $("#tipMsg").text(Label.passwordEmptyLabel);
            $("#userPassword" + status).focus();
        } else {
            return true;
        }
        return false;
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["user-list"] =  {
    "obj": admin.userList,
    "init": admin.userList.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * comment list for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.5, Aug 19, 2011
 */

/* comment-list 相关操作 */
admin.commentList = {
    tablePagination:  new TablePaginate("comment"),
    pageInfo: {
        currentPage: 1
    },
    
    /* 
     * 初始化 table, pagination, comments dialog 
     */
    init: function (page) {
        this.tablePagination.buildTable([{
            text: Label.commentContentLabel,
            index: "content",
            minWidth: 300,
            style: "padding-left: 12px;"
        }, {
            text: Label.titleLabel,
            index: "title",
            width: 300,
            style: "padding-left: 12px;"
        }, {
            text: Label.authorLabel,
            index: "userName",
            width: 120,
            style: "padding-left: 12px;"
        }, {
            text: Label.commentEmailLabel,
            index: "userEmail",
            width: 150,
            style: "padding-left: 12px;"
        }, {
            text: Label.createDateLabel,
            index: "date",
            width: 150,
            style: "padding-left: 12px;"
        }]);
        this.tablePagination.initPagination();
        this.getList(page);
    },

    /* 
     * 根据当前页码获取列表
     * @pagNum 当前页码
     */
    getList: function (pageNum) {
        var that = this;
        $("#loadMsg").text(Label.loadingLabel);
        var requestJSONObject = {
            "paginationCurrentPageNum": pageNum,
            "paginationPageSize": Label.PAGE_SIZE,
            "paginationWindowSize": Label.WINDOW_SIZE
        };
        jsonRpc.commentService.getComments(function (result, error) {
            try {
                switch (result.sc) {
                    case "GET_COMMENTS_SUCC":
                        that.pageInfo.currentPage = pageNum;
                        var comments = result.comments,
                        commentsData = [];
                        for (var i = 0; i < comments.length; i++) {
                            commentsData[i] = {};
                            
                            commentsData[i].content = Util.replaceEmString(comments[i].commentContent);
                            
                            commentsData[i].title = "<a href='" + comments[i].commentSharpURL + 
                            "' target='_blank'>" + comments[i].commentTitle +
                            "</a>";
                        
                            commentsData[i].userName  = "<img class='small-head' src='" + comments[i].commentThumbnailURL + "'/>";
                            if ("http://" === comments[i].commentURL) {
                                commentsData[i].userName += comments[i].commentName;
                            } else {
                                commentsData[i].userName = "<a href='" + comments[i].commentURL +
                                "' target='_blank' class='no-underline'>" + commentsData[i].userName + comments[i].commentName + 
                                "</a>";
                            }
                            
                            commentsData[i].userEmail = "<a href='mailto:" + comments[i].commentEmail +
                            "'>" + comments[i].commentEmail + "</a>";
                        
                            commentsData[i].date = $.bowknot.getDate(comments[i].commentDate.time, 1);
                            
                            var type = "Article"
                            if (comments[i].type === "pageComment") {
                                type = "Page"
                            }
                            commentsData[i].expendRow = "<a href='javascript:void(0)' onclick=\"admin.commentList.del('" +
                            comments[i].oId + "', '" + type + "')\">" + Label.removeLabel + "</a>";
                        }
                        that.tablePagination.updateTablePagination(commentsData, pageNum, result.pagination);
                        break;
                    default:
                        break;
                }
                $("#loadMsg").text("");
            } catch (e) {
                console.error(e);
            }
        }, requestJSONObject);
    },
    
    /* 
     * 删除评论
     * @id 评论 id 
     * @type 评论类型：文章/自定义页面
     */
    del: function (id, type) {
        if (confirm(Label.confirmRemoveLabel)) {
            $("#loadMsg").text(Label.loadingLabel);
            jsonRpc.commentService["removeCommentOf" + type](function (result, error) {
                try {
                    switch (result.sc) {
                        case "REMOVE_COMMENT_FAIL_FORBIDDEN":
                            $("#tipMsg").text(Label.forbiddenLabel);
                            break;
                        case "REMOVE_COMMENT_SUCC":
                            admin.commentList.getList(admin.commentList.pageInfo.currentPage);
                            $("#tipMsg").text(Label.removeSuccLabel);
                            break;
                        case "REMOVE_COMMENT_FAIL_":
                            $("#tipMsg").text(Label.removeFailLabel);
                            break;
                        default:
                            break;
                    }
                    $("#loadMsg").text(Label.loadingLabel);
                } catch (e) {
                    console.error(e);
                }
            }, {
                "oId": id
            });   
        }
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["comment-list"] =  {
    "obj": admin.commentList,
    "init": admin.commentList.init,
    "refresh": admin.commentList.getList
}/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *  plugin manager for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.6, Aug 10, 2011
 */
var plugins = {};
admin.plugin = {
    plugins: [],
    
    /*
     * 添加插件进行管理
     */
    add: function (data) {
        // 添加所有插件
        data.isInit = false;
        data.hash = data.path.replace("/", "#") + "/" + data.id;
        this.plugins.push(data);
        
        var pathList = this._analysePath(data.path);
        // 添加一二级 Tab
        if (data.index && pathList.length < 2) {
            this._addNew(data, pathList);
        }
    },
    
    /*
     * 根据当前 hash 初始化或刷新插件
     */
    setCurByHash: function (tags) {
        var pluginList = this.plugins;
        for (var i = 0; i < pluginList.length; i++) {
            var data = pluginList[i];
            var pathList = this._analysePath(data.path),
            isCurrentPlugin = false;
            
            // 根据当前 hash 和插件 path 判别是非为当前插件
             if (data.index && window.location.hash.indexOf(data.hash) > -1) {
                isCurrentPlugin = true;
            } else if(data.path.replace("/", "#") === window.location.hash ||
                (window.location.hash === "#main" && data.path.indexOf("/main/panel") > -1)) {
                isCurrentPlugin = true;
            }
            
            if (isCurrentPlugin) {
                if (data.isInit) {
                    // 插件已经初始化过，只需进行刷新
                    if (plugins[data.id].refresh) {
                        plugins[data.id].refresh(tags.page);                           
                    }
                } else {
                    // 初始化插件
                    if (!data.index){
                        this._addToExist(data, pathList);
                    } else if (pathList.length === 2) {
                        this._addNew(data, pathList);
                    } 
                    plugins[data.id].init(tags.page);
                    data.isInit = true;
                }
            }
        }  
    },
    
    /*
     * 解析添加路径
     */
    _analysePath: function (path) {
        var paths = path.split("/");
        paths.splice(0, 1);
        return paths;
    },
    
    /*
     * 添加一二级 tab
     */
    _addNew: function (data, pathList) {
        if (pathList.length === 2) {
            data.target = $("#tabPreference li").get(data.index - 1);
            $("#tabPreference").tabs("add", data);
            return;
        } else if (pathList[0] === "") {
            data.target = $("#tabs>ul>li").get(data.index - 1);
        } else if (pathList[0] === "article") {
            data.target = $("#tabArticleMgt>li").get(data.index - 1);
        } else if (pathList[0] === "tools") {
            admin.tools.push("#" + data.id);
            data.target = $("#tabTools>li").get(data.index - 1);
        }
        $("#tabs").tabs("add", data);
    },
    
    /*
     * 在已有页面上进行添加
     */
    _addToExist: function (data, pathList) {
        switch (pathList[0]) {
            case "main":
                $("#mainPanel" + pathList[1].charAt(5)).append(data.content);
                break;
            case "tools":
            case "article":
                if (pathList.length === 2) {
                    $("#tabsPanel_" + pathList[1]).append(data.content);
                } else {
                    $("#tabPreferencePanel_" + pathList[2]).append(data.content);
                }
                break;
            case "comment-list":
                $("#tabsPanel_comment-list").append(data.content);
                break;
        }
    }
};/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * main for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @version 1.0.0.2, Aug 9, 2011
 */

/* main 相关操作 */
admin.main = {
};

/*
 * 注册到 admin 进行管理 
 */
admin.register.main =  {
    "obj": admin.main,
    "init": function () {
        $("#loadMsg").text("");
    },
    "refresh": function () {
        $("#loadMsg").text("");
    }
}
/*
 * Copyright (c) 2009, 2010, 2011, B3log Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *  about for admin
 *
 * @author <a href="mailto:LLY219@gmail.com">Liyuan Li</a>
 * @author <a href="mailto:DL88250@gmail.com">Liang Ding</a>
 * @version 1.0.0.2, Oct 15, 2011
 */

/* about 相关操作 */
admin.about = {
    init: function () {
        $.ajax({
            url: "http://rhythm.b3log.org/version/solo/latest/" + Label.version,
            type: "GET",
            dataType:"jsonp",
            error: function() {
            // alert("Error loading articles from Rhythm");
            },
            success: function(data, textStatus) {
                var version = data.soloVersion;
                if (version === Label.version) {
                    $("#aboutLatest").text(Label.upToDateLabel);
                } else {
                    $("#aboutLatest").html(Label.outOfDateLabel +
                        "<a href='" + data.soloDownload + "'>" + version + "</a>");
                }
                $("#loadMsg").text("");
            }
        });
    }
};

/*
 * 注册到 admin 进行管理 
 */
admin.register["about"] = {
    "obj": admin.about,
    "init": admin.about.init,
    "refresh": function () {
        $("#loadMsg").text("");
    }
}